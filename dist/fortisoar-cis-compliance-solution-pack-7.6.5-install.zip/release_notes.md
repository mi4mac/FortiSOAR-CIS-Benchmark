## Release Notes

Version: 1.0.0
Date: 2026-02-06

### Contents
- CIS compliance modules and relationships
- CIS compliance playbooks
- Roles and permissions (Full App Permissions only)
- Picklists and sample data

### Notes
- Structured package layout aligned to FortiSOAR solution pack conventions.
