# Setup

This solution pack provides CIS compliance modules, picklists, and playbooks.
Import the pack, then verify modules and picklists are created.
Use the playbooks in `playbooks/` to ingest CSV data or evaluate configs.
