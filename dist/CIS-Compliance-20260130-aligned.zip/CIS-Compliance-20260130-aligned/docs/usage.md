# Usage

- `playbook_cis_rules_ingest.json`: CIS Benchmark Rule CSVs
- `playbook_cis_rules_ingest_legacy.json`: legacy CIS Rule CSVs
- `playbook_fortigate_cis_evaluate.json`: FortiGate config evaluation
