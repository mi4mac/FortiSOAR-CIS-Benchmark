# Usage

Use `playbook_cis_rules_ingest.json` for CIS Benchmark Rule CSVs and
`playbook_cis_rules_ingest_legacy.json` for legacy CIS Rule CSVs.
