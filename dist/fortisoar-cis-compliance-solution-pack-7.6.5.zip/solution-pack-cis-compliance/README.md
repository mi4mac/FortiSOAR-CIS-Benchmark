CIS Compliance solution pack for FortiSOAR 7.6.5.
